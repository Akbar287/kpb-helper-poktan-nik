<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <!-- General Info -->
    <meta name="nama" content="<?php echo e(Auth::user()->name); ?>">
    <meta name="id_user" content="<?php echo e(Auth::user()->id); ?>">

    <title><?php echo e(config('app.name', 'e-KPB')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <!-- Google Chart -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
</head>

<body>
    <div id="app">
        <div class="main-wrapper">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <div class="div-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i
                                    class="fas fa-bars"></i></a></li>
                    </ul>
                </div>
                <ul class="navbar-nav navbar-right">
                    <li class="dropdown d-flex">
                        <a href="#" class="nav-link nav-link-lg nav-link-user">
                            <img alt="profile"
                                src="<?php echo e(asset('/images/profile/avatar.png')); ?>"
                                class="rounded-circle mr-1">
                        </a>
                        <a href="<?php echo e(route('logout')); ?>" class="nav-link nav-link-lg nav-link-user" id="logout-btn"
                            onclick="event.preventDefault();">
                            <i class="fas fa-sign-out-alt"></i>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?>
                            </form>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="main-sidebar">
                <aside id="sidebar-wrapper">
                    <div class="sidebar-brand align-items-center">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="logo" class="img-responsive" width="30">
                            Sistem e-KPB</a>
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="logo" class="img-responsive" width="30">
                        </a>
                    </div>
                    <ul class="sidebar-menu">
                        <li class="menu-header">Dashboard</li>
                        <li class="<?php echo e((Route::currentRouteName() == 'home') ? 'active': ''); ?>"><a class="nav-link" href="<?php echo e(url('/home')); ?>"><i class="fas fa-home"></i><span>Dashboard</span></a></li>
                    </ul>
                </aside>
            </div>
            <div class="main-content">
                <section class="section">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            <footer class="main-footer">
                <div class="footer-left">
                    Lampung <?php echo e(now()->year); ?> <div class="bullet"></div> Sistem e-KPB
                </div>
            </footer>
        </div>
    </div>
</body>

</html><?php /**PATH C:\Users\asus\Downloads\Projek\Koding\helper-excel-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>