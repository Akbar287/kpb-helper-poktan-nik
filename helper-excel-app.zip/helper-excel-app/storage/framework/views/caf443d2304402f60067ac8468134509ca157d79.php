<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-sm-12 col-md-10 col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e(__('Dashboard')); ?></h4>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/home')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
                        <div class="row justify-content-center">
                            <div class="col-12 col-sm-12 col-md-8">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="customFile" name="data">
                                    <label class="custom-file-label" for="customFile">Pilih file</label>
                                </div>
                                <div class="text-small">* File Excel (.xls)</div>
                            </div>
                            <div class="col-12 col-sm-12 col-md-4">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Downloads\Projek\Koding\helper-excel-app\resources\views/home.blade.php ENDPATH**/ ?>